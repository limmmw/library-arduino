# esp8266weather
Disini akan disimpan kode yang dipakai untuk membuat sensor dan mengirim datanya ke thingspeak. Menggunakan ESP8266 dan BME280.
